import sys
class Name:
    def __init__(self):
        self.data = self.data_read()
    def data_read(per):
        with open (per, 'r') as file:
            fiel_reader = "".join(file.readlines())
        return fiel_reader
    def output(self):
        print(self.data)
        
def main():
    print(Name.data_read(sys.argv[1]))

if __name__ == "__main__":
    main()