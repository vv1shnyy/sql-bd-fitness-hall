#import pandas
#import csv
#import sys
#class DocType:
#    def data_read():
#        with open ("data/data.csv", "r") as file:
#            fiel_reader = "".join(file.readlines())
#        return fiel_reader
#def main():
#     data_doc = DocType.data_read()
#     print(data_doc)
#if __name__ == "__main__":
#      main()
      
      