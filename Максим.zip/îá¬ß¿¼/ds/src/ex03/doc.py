# import sys
# class Name:
#     def __init__(self):
#         self.data = self.data_read()
#     def data_read(per):
#         with open (per, 'r') as file:
#             fiel_reader = "".join(file.readlines())
#         return fiel_reader
#     def output(self):
#         print(self.data)
        
# def main():
#     print(Name.data_read(sys.argv[1]))


# def check_args():
#     if len(sys.argv) != 2:
#         raise ValueError(" Некорректно количесвто аргументов")
#     else:
#         return sys.argv[1]
# def main():
#     path = check_args()
#     print(Name.data_read(path))
# if __name__ == "__main__":
#     try:
#         main()
#     except ValueError as ve:
#         print(f"{ve}")
#     except Exception as e:
#         print(f"ошибка{e}") python doc.py ../../data/data.csv

import sys
import csv

class Name:
    def __init__(self, file_path):
        self.file_path = file_path
        self.data = self.data_read()

    def data_read(self):
        try:
            with open(self.file_path, 'r') as file:
                reader = csv.reader(file)
                next(reader)
                table_data = [row for row in reader]
            return table_data
        except FileNotFoundError:
            raise Exception(f"Файл '{self.file_path}' не найден.")
        except IOError:
            raise Exception(f"Ошибка при чтении файла '{self.file_path}'.")

    def output(self):
        for row in self.data:
            print(row)

def validate_table(data):
    for line_number, row in enumerate(data, start=2):
        
        cleaned_row = [cell.strip() for cell in row]
        line = ''.join(cleaned_row)
        
        if not all(char in {'0', '1'} for char in line):
            raise ValueError(f"Ошибка в строке {line_number}: найдены недопустимые символы.")
        
        if line.count('1') != 1 or line.count('0') != 1:
            raise ValueError(f"Ошибка в строке {line_number}: в строке должна быть ровно одна '1' и один '0'.")

def check_args():
    if len(sys.argv) != 2:
        raise ValueError("Некорректное количество аргументов. Используйте: python script.py data.csv")
    else:
        return sys.argv[1]

def main():
    path = check_args()
    try:
        name_instance = Name(path)
        validate_table(name_instance.data)
        print("Таблица корректна.")
        name_instance.output()
    except ValueError as ve:
        print(f"Ошибка: {ve}")
    except Exception as e:
        print(f"Ошибка: {e}")

if __name__ == "__main__":
    try:
        main()
    except ValueError as ve:
        print(f"{ve}")
    except Exception as e:
        print(f"Ошибка: {e}")